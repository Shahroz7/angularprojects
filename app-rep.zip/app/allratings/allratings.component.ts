import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allratings',
  templateUrl: './allratings.component.html',
  styleUrls: ['./allratings.component.css']
})
export class AllratingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
