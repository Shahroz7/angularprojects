import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approveratings',
  templateUrl: './approveratings.component.html',
  styleUrls: ['./approveratings.component.css']
})
export class ApproveratingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
