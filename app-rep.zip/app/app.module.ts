import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AlertsModule } from 'angular-alert-module';
import {MatButtonModule} from '@angular/material/button';
import { ButtonsModule, WavesModule, CollapseModule } from 'angular-bootstrap-md';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import {StarRatingModule} from 'angular-star-rating';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginAdminComponent } from './login-admin/login-admin.component';
import { LoginEmpComponent } from './login-emp/login-emp.component';
import { HomeComponent } from './home/home.component';
import { AdminportalComponent } from './adminportal/adminportal.component';
import { RegisterComponent } from './register/register.component';
import { RatingsComponent } from './ratings/ratings.component';
import { EmplportalComponent } from './emplportal/emplportal.component';
import { ReviewComponent } from './review/review.component';
import { LogonComponent } from './logon/logon.component';
import { ContactComponent } from './contact/contact.component';
import { AboutComponent } from './about/about.component';
import { ApproveComponent } from './approve/approve.component';
import { RequestComponent } from './request/request.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HomepageComponent } from './homepage/homepage.component';
import { AllratingsComponent } from './allratings/allratings.component';
import { ApproveratingsComponent } from './approveratings/approveratings.component';
import { RatingdetailsComponent } from './ratingdetails/ratingdetails.component';
import { TestComponent } from './test/test.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginAdminComponent,
    LoginEmpComponent,
    HomeComponent,
    AdminportalComponent,
    RegisterComponent,
    RatingsComponent,
    EmplportalComponent,
    ReviewComponent,
    LogonComponent,
    ContactComponent,
    AboutComponent,
    ApproveComponent,
    RequestComponent,
    NavbarComponent,
    HomepageComponent,
    AllratingsComponent,
    ApproveratingsComponent,
    RatingdetailsComponent,
    TestComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, FormsModule,AlertsModule,ReactiveFormsModule,StarRatingModule.forRoot(),NgbModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
