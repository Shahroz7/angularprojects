import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-ratings',
  templateUrl: './ratings.component.html',
  styleUrls: ['./ratings.component.css']
})
export class RatingsComponent implements OnInit {

  marked = false;
  theCheckbox = false;
  theCheckbox1 = false;
  theCheckbox2 = false;
  theCheckbox3 = false;
  theCheckbox4 = false;
  theCheckbox5 = false;
  theCheckbox6 = false;

  constructor() { }

  ngOnInit() {
  }

  
  toggleVisibility(e){
    this.marked= e.target.checked;
  }
  

}
